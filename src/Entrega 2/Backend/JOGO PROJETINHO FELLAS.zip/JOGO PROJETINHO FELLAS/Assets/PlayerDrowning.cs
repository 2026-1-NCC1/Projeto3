﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerDrowning : MonoBehaviour
{
    [Header("Water Reference")]
    public RisingWater water;

    [Header("Air")]
    public float maxAir = 60f;
    public float currentAir;

    [Header("Health")]
    public float health = 100f;
    public float damagePerSecond = 15f;

    private float logTimer;
    private Rigidbody rb;

    void Start()
    {
        currentAir = maxAir;

        rb = GetComponent<Rigidbody>();

        // 🧨 LIMPA QUALQUER MOVIMENTO INICIAL (resolve “voando”)
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;

            rb.useGravity = true;
            rb.isKinematic = false;
        }
    }

    void Update()
    {
        if (water == null) return;

        bool underwater = transform.position.y < water.GetWaterHeight();

        if (underwater)
        {
            currentAir -= Time.deltaTime;

            if (currentAir <= 0f)
            {
                health -= damagePerSecond * Time.deltaTime;

                if (health <= 0f)
                {
                    Die();
                }
            }
        }
        else
        {
            currentAir += Time.deltaTime * 2f;
            currentAir = Mathf.Clamp(currentAir, 0f, maxAir);
        }

        // 📌 LOG controlado
        logTimer += Time.deltaTime;

        if (logTimer >= 1f)
        {
            Debug.Log("Vida: " + Mathf.Round(health) +
                      " | Ar: " + Mathf.Round(currentAir));

            logTimer = 0f;
        }
    }

    void Die()
    {
        SceneManager.LoadScene("MenuStart");
    }
}