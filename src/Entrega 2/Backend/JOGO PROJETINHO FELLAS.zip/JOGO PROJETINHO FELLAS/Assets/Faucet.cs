﻿using UnityEngine;
using UnityEngine.InputSystem;

public class Faucet : MonoBehaviour
{
    public RisingWater water;

    private bool closed = false;

    [Range(0f, 1f)]
    public float closedMultiplier = 0.3f;

    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Ray ray = Camera.main.ScreenPointToRay(Mouse.current.position.ReadValue());
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider.GetComponentInParent<Faucet>() == this)
                {
                    Debug.Log("CLICOU NA: " + gameObject.name);
                    ToggleFaucet();
                }
            }
        }
    }

    void ToggleFaucet()
    {
        closed = !closed;

        if (water == null)
        {
            Debug.LogError("ÁGUA NÃO CONECTADA EM: " + gameObject.name);
            return;
        }

        water.faucetMultiplier = closed ? closedMultiplier : 1f;

        Debug.Log(gameObject.name + " MULTIPLIER: " + water.faucetMultiplier);
    }
}