using UnityEngine;
using UnityEngine.InputSystem;

public class MouseLook : MonoBehaviour
{
    public float sensibilidade = 2f;

    float xRotation = 0f;
    Transform player;

    Vector2 mouseDelta;

    void Start()
    {
        player = transform.parent;
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        // pega input do mouse
        mouseDelta = Mouse.current.delta.ReadValue();
    }

    void LateUpdate()
    {
        float mouseX = mouseDelta.x * sensibilidade;
        float mouseY = mouseDelta.y * sensibilidade;

        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);

        // c�mera (vertical)
        transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);

        // player (horizontal)
        player.Rotate(Vector3.up * mouseX);
    }
}