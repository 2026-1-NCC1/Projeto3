using UnityEngine;
using UnityEngine.InputSystem;

public class TestInput : MonoBehaviour
{
    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Debug.Log("clicou");
        }
    }
}