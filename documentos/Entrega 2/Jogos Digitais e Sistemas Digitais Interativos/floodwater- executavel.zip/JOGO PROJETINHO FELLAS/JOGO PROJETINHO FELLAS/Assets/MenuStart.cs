using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuStart : MonoBehaviour
{

    public void iniciar()
    { SceneManager.LoadScene("SampleScene");
   }

}
