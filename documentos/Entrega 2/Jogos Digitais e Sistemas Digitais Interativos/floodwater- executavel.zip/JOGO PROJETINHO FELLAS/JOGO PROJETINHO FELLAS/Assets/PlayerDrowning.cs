﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerDrowning : MonoBehaviour
{
    [Header("Water Reference")]
    public RisingWater water;

    [Header("Air")]
    public float maxAir = 60f;
    public float currentAir;

    [Header("Health")]
    public float maxHealth = 100f;
    public float health = 100f;

    public float damagePerSecond = 15f;

    [Header("Head Check")]
    public Transform head;

    private float logTimer;
    private Rigidbody rb;

    void Start()
    {
        currentAir = maxAir;
        health = maxHealth;

        rb = GetComponent<Rigidbody>();

        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;

            rb.useGravity = true;
            rb.isKinematic = false;
        }
    }

    void Update()
    {
        if (water == null || head == null)
            return;

        // verifica a cabeça
        bool underwater = head.position.y < water.GetWaterHeight();

        if (underwater)
        {
            // perde ar
            currentAir -= Time.deltaTime;
            currentAir = Mathf.Clamp(currentAir, 0f, maxAir);

            // sem ar = dano
            if (currentAir <= 0f)
            {
                health -= damagePerSecond * Time.deltaTime;
                health = Mathf.Clamp(health, 0f, maxHealth);

                if (health <= 0f)
                {
                    Die();
                }
            }
        }
        else
        {
            // recupera ar
            currentAir += Time.deltaTime * 2f;
            currentAir = Mathf.Clamp(currentAir, 0f, maxAir);
        }

        // logs
        logTimer += Time.deltaTime;

        if (logTimer >= 1f)
        {
            Debug.Log(
                "Submerso: " + underwater +
                " | Vida: " + Mathf.Round(health) +
                " | Ar: " + Mathf.Round(currentAir)
            );

            logTimer = 0f;
        }
    }

    void Die()
    {
        Debug.Log("PLAYER MORREU AFOGADO");

        SceneManager.LoadScene("MenuStart");
    }
}