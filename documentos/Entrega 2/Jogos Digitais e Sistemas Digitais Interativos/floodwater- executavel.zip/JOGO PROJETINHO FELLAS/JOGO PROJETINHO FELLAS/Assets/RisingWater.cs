﻿using UnityEngine;

public class RisingWater : MonoBehaviour
{
    public float baseSpeed = 0.84f;
    public float maxHeight = 151f;

    [Range(0f, 1f)]
    public float faucetMultiplier = 1f; // 👈 ADICIONA ISSO

    void Update()
    {
        if (transform.position.y < maxHeight)
        {
            float speed = baseSpeed * faucetMultiplier;

            transform.position += Vector3.up * speed * Time.deltaTime;
        }
    }

    public float GetWaterHeight()
    {
        return transform.position.y;
    }
}