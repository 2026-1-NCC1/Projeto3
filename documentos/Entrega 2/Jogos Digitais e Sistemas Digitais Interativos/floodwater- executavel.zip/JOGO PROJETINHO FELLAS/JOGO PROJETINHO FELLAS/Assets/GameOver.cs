using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{

    public void reiniciar()
    {
        SceneManager.LoadScene("SampleScene");
    }

}
