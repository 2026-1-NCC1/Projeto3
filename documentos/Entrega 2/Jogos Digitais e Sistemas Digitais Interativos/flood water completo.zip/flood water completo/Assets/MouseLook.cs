using UnityEngine;
using UnityEngine.InputSystem;

// Classe respons�vel pela movimenta��o da c�mera com o mouse
public class MouseLook : MonoBehaviour
{
    // Sensibilidade do mouse
    public float sensibilidade = 2f;

    // Rota��o vertical da c�mera
    float xRotation = 0f;

    // Refer�ncia ao jogador
    Transform player;

    // Guarda o movimento do mouse
    Vector2 mouseDelta;

    void Start()
    {
        // Pega o objeto pai da c�mera
        player = transform.parent;

        // Trava o cursor no centro da tela
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        // Captura o movimento do mouse
        mouseDelta = Mouse.current.delta.ReadValue();
    }

    void LateUpdate()
    {
        // Movimento horizontal
        float mouseX = mouseDelta.x * sensibilidade;

        // Movimento vertical
        float mouseY = mouseDelta.y * sensibilidade;

        // Inverte o eixo Y para ficar natural
        xRotation -= mouseY;

        // Limita a rota��o vertical
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);

        // Rotaciona a c�mera verticalmente
        transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);

        // Rotaciona o jogador horizontalmente
        player.Rotate(Vector3.up * mouseX);
    }
}