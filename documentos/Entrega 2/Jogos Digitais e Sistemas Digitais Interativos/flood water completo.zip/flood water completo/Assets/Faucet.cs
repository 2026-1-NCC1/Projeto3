﻿using UnityEngine;
using UnityEngine.InputSystem;

// Classe responsável pelas torneiras do jogo
public class Faucet : MonoBehaviour
{
    // Referência para o script da água
    public RisingWater water;

    // Variável que verifica se a torneira já foi fechada
    private bool closed = false;

    // Multiplicador da velocidade da água após fechar a torneira
    // Vai de 0 até 1
    [Range(0f, 1f)]
    public float closedMultiplier = 0.3f;

    void Update()
    {
        // Verifica se o botão esquerdo do mouse foi clicado
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            // Cria um raio da câmera até a posição do mouse
            Ray ray = Camera.main.ScreenPointToRay(Mouse.current.position.ReadValue());
            RaycastHit hit;

            // Verifica se o raio bateu em algum objeto
            if (Physics.Raycast(ray, out hit))
            {
                // Procura um componente Faucet no objeto clicado
                Faucet faucet = hit.collider.GetComponentInParent<Faucet>();

                // Se encontrou uma torneira
                if (faucet != null)
                {
                    // Fecha a torneira
                    faucet.CloseFaucet();
                }
            }
        }
    }

    // Método responsável por fechar a torneira
    public void CloseFaucet()
    {
        // Impede que a torneira seja fechada várias vezes
        if (closed)
            return;

        // Marca como fechada
        closed = true;

        // Verifica se a água foi conectada no Inspector
        if (water == null)
        {
            Debug.LogError("ÁGUA NÃO CONECTADA EM: " + gameObject.name);
            return;
        }

        // Diminui a velocidade da água
        water.faucetMultiplier = closedMultiplier;

        // Mostra mensagem no console
        Debug.Log(gameObject.name + " FOI FECHADA!");
    }
}