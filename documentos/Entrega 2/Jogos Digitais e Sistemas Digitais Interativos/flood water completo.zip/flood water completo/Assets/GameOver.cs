using UnityEngine;
using UnityEngine.SceneManagement;

// Classe respons�vel pela tela de Game Over
public class GameOver : MonoBehaviour
{
    // M�todo para reiniciar o jogo
    public void reiniciar()
    {
        // Carrega novamente a cena principal
        SceneManager.LoadScene("SampleScene");
    }
}