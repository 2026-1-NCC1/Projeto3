using UnityEngine;
using UnityEngine.SceneManagement;

// Classe respons�vel pelo menu inicial
public class MenuStart : MonoBehaviour
{
    // M�todo chamado ao apertar o bot�o de iniciar
    public void iniciar()
    {
        // Carrega a cena principal do jogo
        SceneManager.LoadScene("SampleScene");
    }
}