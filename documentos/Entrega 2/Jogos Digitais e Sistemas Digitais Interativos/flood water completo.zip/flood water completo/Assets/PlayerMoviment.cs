using UnityEngine;
using UnityEngine.InputSystem;

// Classe respons�vel pela movimenta��o do jogador
public class PlayerMoviment : MonoBehaviour
{
    // Velocidade do jogador
    public float speed = 5f;

    // Rigidbody do jogador
    private Rigidbody rb;

    void Start()
    {
        // Pega o Rigidbody do objeto
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        // Vari�vel que armazena o input do teclado
        Vector2 moveInput = Vector2.zero;

        // Movimento para frente
        if (Keyboard.current.wKey.isPressed)
            moveInput.y += 1;

        // Movimento para tr�s
        if (Keyboard.current.sKey.isPressed)
            moveInput.y -= 1;

        // Movimento para esquerda
        if (Keyboard.current.aKey.isPressed)
            moveInput.x -= 1;

        // Movimento para direita
        if (Keyboard.current.dKey.isPressed)
            moveInput.x += 1;

        // Cria dire��o baseada na rota��o do player
        Vector3 move = transform.right * moveInput.x + transform.forward * moveInput.y;

        // Move o Rigidbody
        rb.MovePosition(rb.position + move * speed * Time.deltaTime);
    }
}