﻿using UnityEngine;
using UnityEngine.SceneManagement;

// Classe responsável pelo afogamento do jogador
public class PlayerDrowning : MonoBehaviour
{
    // Referência da água
    [Header("Water Reference")]
    public RisingWater water;

    // Sistema de ar
    [Header("Air")]
    public float maxAir = 60f;
    public float currentAir;

    // Sistema de vida
    [Header("Health")]
    public float maxHealth = 100f;
    public float health = 100f;

    // Dano causado por segundo sem ar
    public float damagePerSecond = 15f;

    // Referência da cabeça do player
    [Header("Head Check")]
    public Transform head;

    // Timer para logs
    private float logTimer;

    // Rigidbody do jogador
    private Rigidbody rb;

    void Start()
    {
        // Define ar inicial
        currentAir = maxAir;

        // Define vida inicial
        health = maxHealth;

        // Pega Rigidbody
        rb = GetComponent<Rigidbody>();

        // Verifica se existe Rigidbody
        if (rb != null)
        {
            // Reseta velocidades
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;

            // Ativa gravidade
            rb.useGravity = true;

            // Garante física ativa
            rb.isKinematic = false;
        }
    }

    void Update()
    {
        // Verifica referências
        if (water == null || head == null)
            return;

        // Verifica se está submerso
        bool underwater = head.position.y < water.GetWaterHeight();

        // Se estiver na água
        if (underwater)
        {
            // Diminui ar
            currentAir -= Time.deltaTime;

            // Limita valor do ar
            currentAir = Mathf.Clamp(currentAir, 0f, maxAir);

            // Sem ar
            if (currentAir <= 0f)
            {
                // Tira vida
                health -= damagePerSecond * Time.deltaTime;

                // Limita vida
                health = Mathf.Clamp(health, 0f, maxHealth);

                // Morreu
                if (health <= 0f)
                {
                    Die();
                }
            }
        }
        else
        {
            // Recupera ar fora da água
            currentAir += Time.deltaTime * 2f;

            // Limita ar
            currentAir = Mathf.Clamp(currentAir, 0f, maxAir);
        }

        // Timer dos logs
        logTimer += Time.deltaTime;

        // Mostra informações a cada 1 segundo
        if (logTimer >= 1f)
        {
            Debug.Log(
                "Submerso: " + underwater +
                " | Vida: " + Mathf.Round(health) +
                " | Ar: " + Mathf.Round(currentAir)
            );

            // Reseta timer
            logTimer = 0f;
        }
    }

    // Método de morte
    void Die()
    {
        Debug.Log("PLAYER MORREU AFOGADO");

        // Volta para menu
        SceneManager.LoadScene("MenuStart");
    }
}