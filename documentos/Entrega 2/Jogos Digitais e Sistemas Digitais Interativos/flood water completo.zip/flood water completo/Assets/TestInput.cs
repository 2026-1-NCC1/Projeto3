using UnityEngine;
using UnityEngine.InputSystem;

// Classe usada apenas para testar entrada do mouse
public class TestInput : MonoBehaviour
{
    void Update()
    {
        // Verifica se o bot�o esquerdo do mouse foi clicado neste frame
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            // Exibe uma mensagem no Console da Unity
            Debug.Log("clicou");
        }
    }
}