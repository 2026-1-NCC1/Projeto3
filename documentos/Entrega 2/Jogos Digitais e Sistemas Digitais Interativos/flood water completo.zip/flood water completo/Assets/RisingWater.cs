﻿using UnityEngine;

// Classe responsável pela subida da água
public class RisingWater : MonoBehaviour
{
    // Velocidade base da água
    public float baseSpeed = 0.84f;

    // Altura máxima da água
    public float maxHeight = 151f;

    // Multiplicador da velocidade da água
    // Pode ser alterado pelas torneiras
    [Range(0f, 1f)]
    public float faucetMultiplier = 1f;

    void Update()
    {
        // Verifica se a água ainda não chegou na altura máxima
        if (transform.position.y < maxHeight)
        {
            // Calcula velocidade final
            float speed = baseSpeed * faucetMultiplier;

            // Move a água para cima
            transform.position += Vector3.up * speed * Time.deltaTime;
        }
    }

    // Retorna a altura atual da água
    public float GetWaterHeight()
    {
        return transform.position.y;
    }
}