using System;
using System.IO;
using System.Text;

namespace Laboratorio404
{
    internal class Program
    {
        static string nomeJogador = "";
        static int energia = 3;
        static int pontos = 0;
        static int faseAtual = 1;
        static bool desistiu = false;
        static bool venceu = false;

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            IniciarJogo();
        }

        static void IniciarJogo()
        {
            MostrarTelaInicial();
            LerNomeJogador();
            MostrarHistoria();

            while (energia > 0 && faseAtual <= 3 && desistiu == false)
            {
                if (faseAtual == 1)
                {
                    JogarFase1();
                }
                else
                {
                    if (faseAtual == 2)
                    {
                        JogarFase2();
                    }
                    else
                    {
                        if (faseAtual == 3)
                        {
                            JogarFase3();
                        }
                    }
                }
            }

            if (faseAtual > 3 && energia > 0 && desistiu == false)
            {
                venceu = true;
            }

            MostrarResultadoFinal();
            SalvarHistorico();
        }

        static void MostrarTelaInicial()
        {
            Console.Clear();
            Console.WriteLine("===============================================");
            Console.WriteLine("            LABORATÓRIO 404");
            Console.WriteLine("===============================================");
            Console.WriteLine("Um jogo em C# de lógica e sobrevivência.");
            Console.WriteLine();
            Console.WriteLine("Você dormiu no laboratório da faculdade.");
            Console.WriteLine("Quando acordou... estava trancado!");
            Console.WriteLine();
            Console.WriteLine("Objetivo:");
            Console.WriteLine("- Passar por 3 fases");
            Console.WriteLine("- Acertar os desafios");
            Console.WriteLine("- Manter sua energia acima de 0");
            Console.WriteLine();
            Console.WriteLine("Regras:");
            Console.WriteLine("- Cada erro tira 1 de energia");
            Console.WriteLine("- Cada acerto dá pontos");
            Console.WriteLine("- Você pode desistir a qualquer momento");
            Console.WriteLine();
            Console.WriteLine("Pressione ENTER para começar...");
            Console.ReadLine();
        }

        static void LerNomeJogador()
        {
            Console.Clear();
            Console.Write("Digite seu nome: ");
            nomeJogador = Console.ReadLine();

            while (string.IsNullOrWhiteSpace(nomeJogador))
            {
                Console.Write("Nome inválido. Digite novamente: ");
                nomeJogador = Console.ReadLine();
            }
        }

        static void MostrarHistoria()
        {
            Console.Clear();
            Console.WriteLine("===============================================");
            Console.WriteLine("                 HISTÓRIA");
            Console.WriteLine("===============================================");
            Console.WriteLine("Olá, " + nomeJogador + "!");
            Console.WriteLine();
            Console.WriteLine("Você estava estudando até tarde e acabou dormindo");
            Console.WriteLine("no laboratório de informática.");
            Console.WriteLine();
            Console.WriteLine("Quando acordou, as luzes estavam fracas,");
            Console.WriteLine("a porta trancada e o sistema de segurança ativo.");
            Console.WriteLine();
            Console.WriteLine("Para sair, você precisa vencer 3 fases:");
            Console.WriteLine("1. Lógica Numérica");
            Console.WriteLine("2. Senha do Sistema");
            Console.WriteLine("3. Terminal Final");
            Console.WriteLine();
            Console.WriteLine("Pressione ENTER para continuar...");
            Console.ReadLine();
        }

        static void MostrarStatus()
        {
            Console.WriteLine();
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine("Jogador: " + nomeJogador);
            Console.WriteLine("Fase atual: " + faseAtual);
            Console.WriteLine("Energia: " + energia);
            Console.WriteLine("Pontos: " + pontos);
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine();
        }

        static bool PerguntarSeDesejaDesistir()
        {
            Console.Write("Deseja desistir? (S/N): ");
            string resposta = Console.ReadLine();

            if (resposta != null)
            {
                resposta = resposta.Trim().ToUpper();
            }

            if (resposta == "S")
            {
                desistiu = true;
                return true;
            }

            return false;
        }

        static void PerderEnergia()
        {
            energia = energia - 1;

            Console.WriteLine();
            Console.WriteLine("Resposta errada! Você perdeu 1 de energia.");
            Console.WriteLine("Energia restante: " + energia);
            Console.WriteLine();

            if (energia > 0)
            {
                Console.WriteLine("Pressione ENTER para tentar novamente...");
                Console.ReadLine();
            }
        }

        static void GanharPontos(int valor)
        {
            pontos = pontos + valor;
            Console.WriteLine();
            Console.WriteLine("Parabéns! Você ganhou " + valor + " pontos.");
            Console.WriteLine("Pontuação atual: " + pontos);
            Console.WriteLine();
        }

        static void JogarFase1()
        {
            bool faseConcluida = false;

            while (faseConcluida == false && energia > 0 && desistiu == false)
            {
                Console.Clear();
                Console.WriteLine("===============================================");
                Console.WriteLine("                 FASE 1");
                Console.WriteLine("             LÓGICA NUMÉRICA");
                Console.WriteLine("===============================================");
                MostrarStatus();

                Console.WriteLine("Para ligar o primeiro terminal, resolva:");
                Console.WriteLine("Qual é o próximo número da sequência?");
                Console.WriteLine("2, 4, 8, 16, ?");
                Console.WriteLine();
                Console.WriteLine("A) 18");
                Console.WriteLine("B) 24");
                Console.WriteLine("C) 32");
                Console.WriteLine("D) 34");
                Console.WriteLine();
                Console.Write("Digite sua resposta ou 'X' para desistir: ");

                string resposta = Console.ReadLine();

                if (resposta != null)
                {
                    resposta = resposta.Trim().ToUpper();
                }

                if (resposta == "X")
                {
                    PerguntarSeDesejaDesistir();
                }
                else
                {
                    if (resposta == "C")
                    {
                        Console.WriteLine();
                        Console.WriteLine("Correto! A sequência dobra a cada passo.");
                        GanharPontos(100);
                        faseAtual = 2;
                        faseConcluida = true;
                        Console.WriteLine("Primeiro terminal ativado!");
                        Console.WriteLine("Pressione ENTER para ir à próxima fase...");
                        Console.ReadLine();
                    }
                    else
                    {
                        PerderEnergia();
                    }
                }
            }
        }

        static void JogarFase2()
        {
            bool faseConcluida = false;

            while (faseConcluida == false && energia > 0 && desistiu == false)
            {
                Console.Clear();
                Console.WriteLine("===============================================");
                Console.WriteLine("                 FASE 2");
                Console.WriteLine("             SENHA DO SISTEMA");
                Console.WriteLine("===============================================");
                MostrarStatus();

                Console.WriteLine("O sistema pede uma senha lógica.");
                Console.WriteLine("Complete a expressão corretamente:");
                Console.WriteLine();
                Console.WriteLine("Se todo computador é uma máquina,");
                Console.WriteLine("e toda máquina precisa de energia,");
                Console.WriteLine("então todo computador precisa de:");
                Console.WriteLine();
                Console.WriteLine("A) Internet");
                Console.WriteLine("B) Energia");
                Console.WriteLine("C) Mouse gamer");
                Console.WriteLine("D) Impressora");
                Console.WriteLine();
                Console.Write("Digite sua resposta ou 'X' para desistir: ");

                string resposta = Console.ReadLine();

                if (resposta != null)
                {
                    resposta = resposta.Trim().ToUpper();
                }

                if (resposta == "X")
                {
                    PerguntarSeDesejaDesistir();
                }
                else
                {
                    if (resposta == "B")
                    {
                        Console.WriteLine();
                        Console.WriteLine("Correto! Boa dedução lógica.");
                        GanharPontos(150);
                        faseAtual = 3;
                        faseConcluida = true;
                        Console.WriteLine("Segundo terminal ativado!");
                        Console.WriteLine("Pressione ENTER para ir à fase final...");
                        Console.ReadLine();
                    }
                    else
                    {
                        PerderEnergia();
                    }
                }
            }
        }

        static void JogarFase3()
        {
            bool faseConcluida = false;

            while (faseConcluida == false && energia > 0 && desistiu == false)
            {
                Console.Clear();
                Console.WriteLine("===============================================");
                Console.WriteLine("                 FASE 3");
                Console.WriteLine("              TERMINAL FINAL");
                Console.WriteLine("===============================================");
                MostrarStatus();

                Console.WriteLine("Última trava de segurança.");
                Console.WriteLine("Resolva o desafio final:");
                Console.WriteLine();
                Console.WriteLine("Um laço while é usado principalmente para:");
                Console.WriteLine();
                Console.WriteLine("A) Guardar imagens");
                Console.WriteLine("B) Repetir instruções enquanto uma condição for verdadeira");
                Console.WriteLine("C) Pintar a tela");
                Console.WriteLine("D) Desligar o computador");
                Console.WriteLine();
                Console.Write("Digite sua resposta ou 'X' para desistir: ");

                string resposta = Console.ReadLine();

                if (resposta != null)
                {
                    resposta = resposta.Trim().ToUpper();
                }

                if (resposta == "X")
                {
                    PerguntarSeDesejaDesistir();
                }
                else
                {
                    if (resposta == "B")
                    {
                        Console.WriteLine();
                        Console.WriteLine("Correto! Você domina a lógica de programação.");
                        GanharPontos(200);
                        faseAtual = 4;
                        faseConcluida = true;
                        Console.WriteLine("Terminal final ativado!");
                        Console.WriteLine("A porta do laboratório foi destrancada.");
                        Console.WriteLine("Pressione ENTER para ver o resultado...");
                        Console.ReadLine();
                    }
                    else
                    {
                        PerderEnergia();
                    }
                }
            }
        }

        static void MostrarResultadoFinal()
        {
            Console.Clear();
            Console.WriteLine("===============================================");
            Console.WriteLine("              RESULTADO FINAL");
            Console.WriteLine("===============================================");
            Console.WriteLine("Jogador: " + nomeJogador);
            Console.WriteLine("Pontos finais: " + pontos);
            Console.WriteLine("Energia final: " + energia);
            Console.WriteLine();

            if (venceu == true)
            {
                Console.WriteLine("STATUS: VOCÊ VENCEU!");
                Console.WriteLine("Você escapou do laboratório com sucesso.");
            }
            else
            {
                if (desistiu == true)
                {
                    Console.WriteLine("STATUS: VOCÊ DESISTIU.");
                    Console.WriteLine("Você decidiu esperar alguém abrir a porta.");
                }
                else
                {
                    if (energia <= 0)
                    {
                        Console.WriteLine("STATUS: GAME OVER.");
                        Console.WriteLine("Sua energia acabou antes de fugir.");
                    }
                    else
                    {
                        Console.WriteLine("STATUS: JOGO ENCERRADO.");
                    }
                }
            }

            Console.WriteLine();
            Console.WriteLine("O histórico desta partida foi salvo em arquivo texto.");
            Console.WriteLine();
            Console.WriteLine("Pressione ENTER para finalizar...");
            Console.ReadLine();
        }

        static void SalvarHistorico()
        {
            string pasta = AppDomain.CurrentDomain.BaseDirectory;
            string caminhoArquivo = Path.Combine(pasta, "historico_resultados.txt");

            string resultado = "";

            if (venceu == true)
            {
                resultado = "VENCEU";
            }
            else
            {
                if (desistiu == true)
                {
                    resultado = "DESISTIU";
                }
                else
                {
                    if (energia <= 0)
                    {
                        resultado = "DERROTA";
                    }
                    else
                    {
                        resultado = "ENCERRADO";
                    }
                }
            }

            string linha = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")
                         + " | Jogador: " + nomeJogador
                         + " | Pontos: " + pontos
                         + " | Energia: " + energia
                         + " | Resultado: " + resultado;

            File.AppendAllText(caminhoArquivo, linha + Environment.NewLine);
        }
    }
}
